console.log("script.js loaded");

function uploadFrames() {
    const input = document.getElementById("frameInput");
    const result = document.getElementById("result");

    if (input.files.length === 0) {
        alert("Please select image frames");
        return;
    }

    const formData = new FormData();

    for (let i = 0; i < input.files.length; i++) {
        formData.append("frames", input.files[i]);
    }

    result.innerText = "Processing frames...";

    fetch("/predict", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        console.log("Backend response:", data); // 🔍 debug

        if (data.error) {
            result.innerText = data.error;
        } else {
            result.innerHTML = `
                <h3>Prediction Result</h3>
                <p><strong>Action:</strong> ${data.prediction}</p>
                <p><strong>Confidence:</strong> ${(data.confidence * 100).toFixed(2)}%</p>
                <p><strong>Caption:</strong> ${data.caption}</p>
            `;
        }
    })
    .catch(error => {
        console.error(error);
        result.innerText = "Error occurred!";
    });
}
