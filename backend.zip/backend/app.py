import os
import numpy as np
from flask import Flask, render_template, request, jsonify
from tensorflow.keras.models import load_model
from feature_extractor import extract_features

# ---------------- CONFIG ----------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

MODEL_PATH = os.path.join(BASE_DIR, "hmdb_lstm_model.h5")
LABEL_PATH = os.path.join(BASE_DIR, "hmdb_label_classes.npy")

# ---------------- LOAD MODEL ----------------
model = load_model(MODEL_PATH)
class_names = np.load(LABEL_PATH)

ACTION_CAPTIONS = {
    "catch": "A person is catching.",
    "chew": "A person is chewing.",
    "clap": "A person is clapping.",
    "drink": "A person is drinking water.",
    "eat": "A person is eating.",
    "pick": "A person picking an object.",
    "pour": "A person is pouring drink.",
    "punch": "A person is punching.",
    "push": "A person is pushing the object.",
    "run": "A person is running.",
    "sit": "A person is sitting down.",
    "stand": "A person is standing.",
    "walk": "A person is walking.",
    "wave": "A person is waving.",
}
# ---------------- ACTION → CAPTION MAP ----------------

# ---------------- FLASK APP ----------------
app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "frontend"),
    static_folder=os.path.join(BASE_DIR, "static")
)

# ---------------- HOME ----------------
@app.route("/")
def home():
    return render_template("index.html")

# ---------------- PREDICT ROUTE ----------------
@app.route("/predict", methods=["POST"])
def predict():
    print("Received predict request")

    if "frames" not in request.files:
        return jsonify({"error": "No frames uploaded"})

    frames_files = request.files.getlist("frames")

    if len(frames_files) == 0:
        return jsonify({"error": "No frames uploaded"})

    # Create temp directory
    temp_dir = os.path.join(UPLOAD_FOLDER, "frames_temp")
    os.makedirs(temp_dir, exist_ok=True)

    # Save frames
    for i, file in enumerate(frames_files):
        file.save(os.path.join(temp_dir, f"frame_{i:03d}.jpg"))

    try:
        # Feature extraction
        features = extract_features(temp_dir)
        print("Features shape:", features.shape)

        # Prediction
        prediction = model.predict(features)
        class_index = int(np.argmax(prediction))
        confidence = float(np.max(prediction))

        predicted_class = class_names[class_index]

        # -------- CAPTION GENERATION --------
        caption = ACTION_CAPTIONS.get(
            predicted_class,
            f"A person is performing the action: {predicted_class}."
        )

    except Exception as e:
        return jsonify({"error": f"Prediction failed: {str(e)}"})

    finally:
        # Cleanup temp folder
        for f in os.listdir(temp_dir):
            os.remove(os.path.join(temp_dir, f))

    return jsonify({
        "prediction": predicted_class,
        "confidence": round(confidence, 4),
        "caption": caption
    })

# ---------------- RUN APP ----------------
if __name__ == "__main__":
    app.run(debug=True)
