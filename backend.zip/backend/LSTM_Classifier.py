import numpy as np
import os
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.utils import to_categorical

# -------- Load Features --------
FEATURE_PATH = r"E:\archive\HMDB51_features"

X = np.load(os.path.join(FEATURE_PATH, "X_features.npy"))
y = np.load(os.path.join(FEATURE_PATH, "y_labels.npy"))

# -------- Encode Labels --------
le = LabelEncoder()
y_encoded = to_categorical(le.fit_transform(y))
NUM_CLASSES = y_encoded.shape[1]

# -------- Train / Test Split --------
X_train, X_test, y_train, y_test = train_test_split(
    X, y_encoded,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# -------- LSTM Model --------
model = Sequential([
    LSTM(256, return_sequences=False, input_shape=(X.shape[1], X.shape[2])),
    Dropout(0.5),
    Dense(128, activation="relu"),
    Dense(NUM_CLASSES, activation="softmax")
])

model.compile(
    optimizer="adam",
    loss="categorical_crossentropy",
    metrics=["accuracy"]
)

model.summary()

# -------- Train --------
history = model.fit(
    X_train, y_train,
    validation_data=(X_test, y_test),
    epochs=30,
    batch_size=8
)

# -------- Save --------
model.save("hmdb_lstm_model.h5")
np.save("hmdb_label_classes.npy", le.classes_)

print("LSTM training completed!")
