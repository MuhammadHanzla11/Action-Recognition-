import os
import cv2
import numpy as np
from tqdm import tqdm
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.models import Model
from tensorflow.keras.layers import GlobalAveragePooling2D

# ================= CONFIG =================
DATASET_PATH = r"E:\archive\HMDB51"
FEATURE_SAVE_PATH = r"E:\archive\HMDB51_features"
IMG_SIZE = 224
SEQUENCE_LENGTH = 16
MAX_SEQUENCES_PER_CLASS = 30
# =========================================

os.makedirs(FEATURE_SAVE_PATH, exist_ok=True)

# -------- Load CNN --------
base_model = MobileNetV2(
    weights="imagenet",
    include_top=False,
    input_shape=(IMG_SIZE, IMG_SIZE, 3)
)

cnn = Model(
    inputs=base_model.input,
    outputs=GlobalAveragePooling2D()(base_model.output)
)

# -------- Frame Loader --------
def load_frames(folder):
    images = sorted([
        img for img in os.listdir(folder)
        if img.lower().endswith(('.jpg', '.png'))
    ])

    step = max(len(images) // SEQUENCE_LENGTH, 1)
    frames = []

    for i in range(0, len(images), step):
        if len(frames) == SEQUENCE_LENGTH:
            break

        img = cv2.imread(os.path.join(folder, images[i]))
        img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
        img = preprocess_input(img)
        frames.append(img)

    while len(frames) < SEQUENCE_LENGTH:
        frames.append(frames[-1])

    return np.array(frames)

# -------- Feature Extraction --------
X_features, y_labels = [], []

class_names = sorted(os.listdir(DATASET_PATH))

print("Extracting CNN features...")

for action in class_names:
    action_path = os.path.join(DATASET_PATH, action)
    if not os.path.isdir(action_path):
        continue

    sequences = os.listdir(action_path)[:MAX_SEQUENCES_PER_CLASS]

    for seq in tqdm(sequences, desc=f"{action}"):
        seq_path = os.path.join(action_path, seq)
        if not os.path.isdir(seq_path):
            continue

        frames = load_frames(seq_path)
        features = cnn.predict(frames, verbose=0)   # (16, 1280)

        X_features.append(features)
        y_labels.append(action)

X_features = np.array(X_features)
y_labels = np.array(y_labels)

np.save(os.path.join(FEATURE_SAVE_PATH, "X_features.npy"), X_features)
np.save(os.path.join(FEATURE_SAVE_PATH, "y_labels.npy"), y_labels)

print("Feature extraction completed!")
print("X_features shape:", X_features.shape)
