import os
import cv2
import numpy as np
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.models import Model
from tensorflow.keras.layers import GlobalAveragePooling2D

IMG_SIZE = 224
SEQUENCE_LENGTH = 16  # number of frames for LSTM

# Load MobileNetV2
base_model = MobileNetV2(weights="imagenet", include_top=False, input_shape=(IMG_SIZE, IMG_SIZE, 3))
cnn = Model(inputs=base_model.input, outputs=GlobalAveragePooling2D()(base_model.output))

def load_frames(folder):
    images = sorted([
        img for img in os.listdir(folder)
        if img.lower().endswith(('.jpg', '.png', '.jpeg'))
    ])

    # Pick exactly 16 frames
    step = max(len(images) // SEQUENCE_LENGTH, 1)
    frames = []

    for i in range(0, len(images), step):
        if len(frames) == SEQUENCE_LENGTH:
            break
        img = cv2.imread(os.path.join(folder, images[i]))
        img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
        img = preprocess_input(img)
        frames.append(img)

    # Pad last frame if less than 16
    while len(frames) < SEQUENCE_LENGTH:
        frames.append(frames[-1])

    return np.array(frames)

def extract_features(folder):
    frames = load_frames(folder)
    features = cnn.predict(frames, verbose=0)
    return np.expand_dims(features, axis=0)  # shape: (1, 16, 1280)
